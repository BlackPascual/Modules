package com.example.a03hands_onactivity2arg;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    public static final String EXTRA_MESSAGE = "com.example.registration.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText txtLastName = findViewById(R.id.txtLastName);
        EditText txtEmail = findViewById(R.id.txtEmail);
        EditText txtPassword = findViewById(R.id.txtPassword);
        EditText txtConfirmPassword = findViewById(R.id.txtConfirmPassword);
        Button btnCreate = findViewById(R.id.btnCreate);



        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String lName, Emaill, Password, ConfirmPassword;

                lName = txtLastName.getText().toString();
                Emaill = txtEmail.getText().toString();
                Password = txtPassword.getText().toString();
                ConfirmPassword = txtConfirmPassword.getText().toString();
                openActivity();
            }
        });
    }
    public void openActivity(){
        Intent intent = new Intent(this, NewActivity.class);
        EditText txtFirstName = findViewById(R.id.txtFirstName);
        String fName = txtFirstName.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, fName);
        startActivity(intent);
    }



}