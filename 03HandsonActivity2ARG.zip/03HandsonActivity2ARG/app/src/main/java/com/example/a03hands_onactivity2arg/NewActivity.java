package com.example.a03hands_onactivity2arg;


import static com.example.a03hands_onactivity2arg.MainActivity.EXTRA_MESSAGE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class NewActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        TextView txtResult = findViewById(R.id.txtResult);
        Intent intent = getIntent();

        String fName = intent.getStringExtra(EXTRA_MESSAGE);

        txtResult.setText("Welcome to Google, " + fName + "!");

    }
}