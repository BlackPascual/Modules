package com.example.registration;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText FirstName = findViewById(R.id.FirstName);
        EditText LastName = findViewById(R.id.LastName);
        EditText Email = findViewById(R.id.Email);
        EditText Passwords = findViewById(R.id.Passwords);
        EditText ConfirmPasswords = findViewById(R.id.ConfirmPasswords);
        Button Creates = findViewById(R.id.Creates);

        Activity2 act2 = new Activity2();

        Creates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Act2();
            }
        });
    }
    private void Act2(){
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
    }

}