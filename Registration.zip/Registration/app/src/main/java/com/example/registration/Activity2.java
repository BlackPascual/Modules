package com.example.registration;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(getApplicationContext(), "Successfully Created The Activity!", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_2);
    }
}